package javaproject4thsem;
//10---USAGE OF CLASSES IN DIFFERENT PACKAGES
import jproject.*;

import java.util.Scanner;//scanner

//13---THREAD CREATION USING EXTENDING THREADS
 class company extends Thread{
	 
   
//14---THREAD SYNCHRONIZTION	  
	 public synchronized void run()
		{
			try
			{
				for(int i=3;i>0;i--)
			   System.out.println(i);
			   Thread.sleep(1000);
			}
			catch(Exception e)
			{
				System.out.println("Thread interrupted");
			}
	
        }
 }

//12----INTERFACES WITH VARIABLES
interface cabcompany
{
	
	String cname="PASSENGERS CAB COMPANY" ;
	 public void companygreetings();
//11----IMPPLEMENTING INTERFACE WITH DEFAULT METHOD
	default void details() 
	{
		System.out.println("We are selecting the best employee in the company");
		
	}
}

//1---CLASS DECLARATION
class Employee implements cabcompany    //superclass
{
	String name;
	int workingexperience;//instance variables
	int age;
	float salary;
	int recommendation;
	
	
	Employee()
	{
	name="Suresh";
	workingexperience=4;
	age=23;
	salary=1000;
	recommendation=6;
	}
	
//2---PASSING DATATYPES AS PARAMETER TO A CONSTRUCTOR
	Employee (float salary)      //  parametrized constructor
	{
		name="Ramesh";
		 workingexperience=6;
		  age=32;
//4---USAGE OF THIS KEYWORD
		  this.salary=salary;
		 recommendation=5;
		 
	    }
	
	
	
//2---PASSING OBJECT AS PARAMETER TO A CONSTRUCTOR	
	Employee (Employee ob)              //passing object to constructor
	{
	  this.name=ob.name;
	  this.workingexperience=ob.workingexperience;
	   age=ob.age;
	   salary=ob.salary;
	   recommendation=ob.recommendation;
	}
	 public void companygreetings()
	 {
		 System.out.println("HELLO EVERYONE!!!");
		 System.out.println();
	 }
	 
	  
	 public void companyprogram()         //method
	{
		System.out.println("Welcome to Best employee of "+ cname +" selection process");
		  System.out.println();
		 
	}
   
    

//3-----RETURNING OBJECTS FROM METHOD
     Employee salaryincreemented()   //Returning objects from method
      {
   	    System.out.println("BEGINNING SALARY :"+ salary);
   	    Employee temp = new Employee(salary+1000);
   	    return temp; 
      }
     void display__incrementedsalary( )
     {
   	   System.out.println("INCREMENTED SALARY:"+ salary);
	       
      }
     
}
//5--MULTILEVEL INHERITENCE
   class Driver extends Employee
  {
     int driverid ;
	
	
	
	Driver()
	{
		super();
		driverid=134;
	
	}
	
	
	Driver(float salary)
	{
    	super(salary);
    	driverid=456;
    	
	}	
	Driver (Driver ob)              
	{
//5--PASSING OBJECT TO CONSTRUCTOR IN SUPER			
	  super(ob);
	  driverid=ob.driverid;
  	  
	}
	
	
	 public void companyprogram()
	{
		super.companyprogram();
		
	}
	
	 Employee salaryincreemented()   //Returning objects from method
     {
		 return super.salaryincreemented();
	  	   
     }
    void display__incrementedsalary( )
    {
  	   super.display__incrementedsalary();
	       
     }
   
	 }
   class cabdriver extends Driver
   {
	   int cabnum;
	   double rating;
	   
	   cabdriver()
	   {
	     super();
	     cabnum=9;
	     rating=4;
      }

	   cabdriver(float salary)
	   {
		   super(salary);
		   cabnum=56;
		   rating=3.6;
	   }
       
	   cabdriver(cabdriver ob)
	   {
		   super(ob);
		   cabnum=ob.cabnum;
		   rating=ob.rating;
	   }
//6---OVERRIDING METHODS
	 public void companyprogram()
	{
		super.companyprogram();
		
		
	}
	 
	  Employee salaryincreemented()   //Returning objects from method
     {
  	    return super.salaryincreemented();
  	   
     }
    void display__incrementedsalary( )
    {
  	   super.display__incrementedsalary();
     }
		   
	   }
//9---CUSTOM EXCEPTION 
class lessratingexception extends Exception{               
	   
	   lessratingexception(String s)
	   {
		super(s);  
       }
}
	public class bestemployee {
		public static void main(String[] args)
       
        {
			
			String s1="good";
			String s2="bad";
//8--STRING CONCATENATION--------> HANDLING FUNCTION 			
		    String wish="Congratulations"+" to the"+" BEST EMPLOYEE" +" winner."; 
			
		    Scanner sc= new Scanner(System.in);
		    
		   
		    cabcompany obj=new Employee();
//1----OBJECT DECLARATION			  
		  Employeequalities good= new Employeequalities();
		 
			 Employee obj1= new Employee();
		     Employee obj2= new Employee(8000);
		     Driver  driver1=new Driver();
		     Driver  driver2=new Driver(3000);
		     cabdriver cdriver1= new cabdriver();
		     cabdriver cdriver2=new cabdriver(3000);
		     
		     
		     
		     
		     obj.companygreetings();
//6---OBJECT CREATED FOR OVERRIDDEN METHOD	     
			  cdriver1.companyprogram();
			  obj.details();
			  System.out.println();
		    
	 
		  good.qualitiesofemp();
		  System.out.println();
		  System.out.println("-----------------------------------------------------------------------------");
		  System.out.println("Check whether you are eligible for BEST EMPLOYEE category");
		 
		  System.out.println("Enter your review GOOD or BAD");
//7---READING CONSOLE INPUT(nextLine())USING SCANNER CLASS
		  String rew=sc.nextLine();
		  System.out.println();
//8--STRING CAMPARISION-------------->STRING HANDLING FUNCTION
		  System.out.println(rew.equals(s1));
		  if(rew.equalsIgnoreCase(s1)== true) 
		  {
			  
			  System.out.println("REVIEWS  matches the  eligibility criteria ");  
			  System.out.println();
		  }
		   else 
		   {
			  System.out.println("REVIEWS does not  match the  eligibility criteria  ");
			  System.out.println();
		 
		  }
		  
		  System.out.println("-----------------------------------------------------------------------");
		  System.out.println("Enter your ratings :");
//7---READING CONSOLE INPUT(nextInt())USING SCANNER CLASS
		    	  double rating=sc.nextInt();                
		    	 if (rating < 3)
		    	 {
			       try 
			       {
			    	
			    	 throw new lessratingexception("RATINGS  does not match the  eligibility criteria ");
			       }
			      catch(lessratingexception ex) 
			       {
			    	 
			    	 System.out.println(ex.getMessage());
			 	  }
		        }
		    	  else
			 	     {
			 	    	 System.out.println("RATINGS  matches the  eligibility criteria");
			 	    	 
			 	     }
		    	 
		    	 System.out.println("-----------------------------------------------------------------------");
		    	 if(rew.equalsIgnoreCase(s1)== true && rating > 3)
		    	 {
		    		 System.out.println("Eligible for BEST EMPLOYEE category");
		    		 System.out.println();
		    	 }
		    	 else
		    	 {
		    		 System.out.println("Not eligible for BEST EMPLOYEE category"); 
		    		 System.out.println();
		    		
		    	 }
		    	 
		    	 
	    	 
		
		  System.out.println("DETAILS OF  3 EMPLOYEE SELECTED FOR BEST EMPLOYEE CATEGORY");
		  System.out.println();
		  
		 
		  
	            System.out.println("Details of Employee 1:");
				System.out.println("Name " +":");
//7---READING CONSOLE INPUT(next())USING SCANNER CLASS
				String name1 = sc.next();
				System.out.println("Working Experience"+": ");
				 int experience1=sc.nextInt();
				System.out.println("Number of employee recommended"+":");
				 int recommend1=sc.nextInt();
				System.out.println("Ratings"+":");
				 int r1=sc.nextInt();
				 System.out.println();
				 
				 System.out.println("Details of Employee 2:");
				 System.out.println("Name " +":");
					String name2 = sc.next();
					System.out.println("Working Experience"+": ");
					 int experience2=sc.nextInt();
					System.out.println("Number of employee recommended"+":");
					 int recommend2=sc.nextInt();
					System.out.println("Ratings"+":");
					 int r2=sc.nextInt();
					 System.out.println();
					 
				 System.out.println("Details of Employee 3:");
				 System.out.println("Name " +":");
					String name3 = sc.next();
					System.out.println("Working Experience"+": ");
					 int experience3=sc.nextInt();
					System.out.println("Number of employee recommended"+":");
					 int recommend3=sc.nextInt();
					System.out.println("Ratings"+":");
					 int r3=sc.nextInt();
					 System.out.println();
			
			
					

					 company c1=new company();
					 company c2=new company();
					 System.out.println("COUNT :");
					 c1.start();
					 c2.start();
					 try
					 {
						 c1.join();
						 c2.join();
					 }
					 catch(Exception e)
					 {
					 System.out.println("!!!");
					 }
					 System.out.println("AND THE WINNER IS!!!");
		    
	    	
	    	 System.out.println();
			  System.out.println("-----------------------------------------------------------------------------");
			  
			 if(recommend1 > recommend2 && recommend1>recommend3) 
			 {
				 System.out.println("Employee 1 is the BEST EMPLOYEE");
				 System.out.println("NAME :"+name1+"\nEXPERIENCE :"+experience1+"\nNUMBER OF RECOMMENDATIONS :"+recommend1+"\nRATINGS:"+r1);
				 obj2=obj2.salaryincreemented(); 
			     obj2.display__incrementedsalary();
			     
			     System.out.println(wish);
			     
			 }
			 else if(recommend2 > recommend1 && recommend2 >recommend3) 
			 {
				 System.out.println("Employee 2 is the BEST EMPLOYEE");
				 System.out.println("NAME :"+name2+"\nEXPERIENCE :"+experience2+"\nNUMBER OF RECOMMENDATIONS :"+recommend2+"\nRATINGS :"+r2);
				 obj2=obj2.salaryincreemented(); 
			     obj2.display__incrementedsalary();
			     
			     System.out.println(wish);
			     
			 }
			 else if(recommend3 > recommend1 && recommend3>recommend1) 
			 {
				 System.out.println("Employee 3 is the BEST EMPLOYEE");
				 System.out.println("NAME :"+name3+"\nEXPERIENCE :"+experience3+"\nNUMBER OF RECOMMENDATIONS :"+recommend3+"\nRATINGS :"+r3);
				 obj2=obj2.salaryincreemented(); 
			     obj2.display__incrementedsalary();
			     
			     System.out.println(wish);
			     
			 }
			 else if(recommend1 == recommend2 )
			 {
				 if(r1>r2)
			   {
				 System.out.println("Employee 1 is the BEST EMPLOYEE");
				 System.out.println("NAME :"+name1+"\nEXPERIENCE :"+experience1+"\nNUMBER OF RECOMMENDATIONS :"+recommend1+"\nRATINGS:"+r1);
				 obj2=obj2.salaryincreemented(); 
			     obj2.display__incrementedsalary();
			     
			     System.out.println(wish);
			     
			   }
				 else
				
					 System.out.println("Employee 2 is the BEST EMPLOYEE");
				 System.out.println("NAME :"+name2+"\nEXPERIENCE :"+experience2+"\nNUMBER OF RECOMMENDATIONS :"+recommend2+"\nRATINGS:"+r2);
				 obj2=obj2.salaryincreemented(); 
			     obj2.display__incrementedsalary();
			     
			     System.out.println(wish);
			     
			   
			 }
			 else if(recommend2 == recommend3 )
			 {
				 
					 if(r2>r3)
				   {
					 System.out.println("Employee 2 is the BEST EMPLOYEE");
					 System.out.println("NAME :"+name2+"\nEXPERIENCE :"+experience2+"\nNUMBER OF RECOMMENDATIONS :"+recommend2+"\nRATINGS :"+r2);
					 obj2=obj2.salaryincreemented(); 
				     obj2.display__incrementedsalary();
				     
				     System.out.println(wish);
				     
				   }
					 else
				     System.out.println("Employee 3 is the BEST EMPLOYEE");
					 System.out.println("NAME :"+name3+"\nEXPERIENCE :"+experience3+"\nNUMBER OF RECOMMENDATIONS :"+recommend3+"\nRATINGS :"+r3);
					 obj2=obj2.salaryincreemented(); 
				     obj2.display__incrementedsalary();
				     
				     System.out.println(wish);
				     
				 
			 }
			 
			 else if(recommend3 == recommend1 )
			 {
				 
				   if(r3>r1) 
				  {
					 System.out.println("Employee 3 is the BEST EMPLOYEE");
					 System.out.println("NAME :"+name3+"\nEXPERIENCE :"+experience3+"\nNUMBER OF RECOMMENDATIONS :"+recommend3+"\nRATINGS :"+r3);
					 obj2=obj2.salaryincreemented(); 
				     obj2.display__incrementedsalary();
				     
				     System.out.println(wish);
				     
				   }
					 else 
				  
						 System.out.println("Employee 1 is the BEST EMPLOYEE");
					 System.out.println("NAME :"+name1+"\nEXPERIENCE :"+experience1+"\nNUMBER OF RECOMMENDATIONS :"+recommend1+"\nRATINGS :"+r1);
					 obj2=obj2.salaryincreemented(); 
				     obj2.display__incrementedsalary();
				     
				     System.out.println(wish);
				     
			 }
				 
			 
			   
			 else 
			 {
				 System.out.println("Plz enter unique values");
			 }
			 System.out.println("----------------------------------------------------------------------------------------");
		
	       
	  
	  	  
			 
        
		    	 }
	}
        

     


