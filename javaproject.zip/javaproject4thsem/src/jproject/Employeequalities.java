package jproject;

//10---USAGE OF CLASSES IN DIFFERENT PACKAGES
public class Employeequalities {
	
	 public Employeequalities(){
		
		System.out.println("------------------------------------------------------------------------------------ ");
	}
	
	 public void qualitiesofemp()
	{
		System.out.println("Required qualities for best Employee  :");
		System.out.println();
		System.out.println(" 1.Best rating from passengers.");
		System.out.println(" 2.GOOD review from customers.");
		System.out.println(" 3.Minimum workingexperience. ");
		System.out.println(" 4.With  minimum annual leave.");
		System.out.println(" 5.Recomendation from  other employees to select you as best employee.");
		System.out.println(" 6.With  best work performance.");
		
		
	}
}